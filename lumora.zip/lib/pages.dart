import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'api.dart';
import 'main.dart';
import 'mcp.dart';
import 'oauth.dart';
import 'store.dart';
import 'package:webview_flutter/webview_flutter.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final b = TextEditingController(text: Api.baseUrl);
  final k = TextEditingController(text: Api.apiKey);
  String status = '';
  bool busy = false, ok = false;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    b.addListener(_auto);
    k.addListener(_auto);
    if (Api.ready) _check();
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  void _auto() {
    _t?.cancel();
    if (b.text.trim().isEmpty || k.text.trim().length < 8) return;
    _t = Timer(const Duration(milliseconds: 900), _check);
  }

  Future<void> _check() async {
    if (!mounted) return;
    setState(() {
      busy = true;
      ok = false;
      status = 'Checking...';
    });
    try {
      final m = await Api.check(b.text, k.text);
      if (mounted) {
        setState(() {
          ok = true;
          status = 'Connected (${Api.proto} format). ${m.length} models available.';
        });
      }
    } catch (e) {
      if (mounted) setState(() => status = Api.explain(e));
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('API key')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          TextField(
              controller: b,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(
                  labelText: 'Base URL',
                  hintText: 'https://api.example.com',
                  border: OutlineInputBorder())),
          const SizedBox(height: 14),
          TextField(
              controller: k,
              obscureText: true,
              decoration: const InputDecoration(
                  labelText: 'API key', border: OutlineInputBorder())),
          const SizedBox(height: 18),
          FilledButton(
              style: FilledButton.styleFrom(backgroundColor: accent),
              onPressed: busy ? null : _check,
              child: const Text('Test models')),
          if (status.isNotEmpty)
            Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Text(status,
                    style: TextStyle(
                        color: ok ? Colors.green.shade700 : Colors.red.shade700))),
          const SizedBox(height: 14),
          OutlinedButton(
              onPressed: () async {
                await Api.save(b.text, k.text);
                if (context.mounted) Navigator.pop(context, true);
              },
              child: const Text('Save')),
        ]),
      );
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  Map<String, dynamic>? q;
  int? nModels;
  String err = '';
  bool loading = true;
  final lim = TextEditingController(
      text: Store.limit == 0 ? '' : Store.limit.toString());
  String get _mk => DateTime.now().toIso8601String().substring(0, 7);

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() => loading = true);
    final qf = Api.quotaInfo();
    try {
      nModels = (await Api.models()).length;
      err = '';
    } catch (e) {
      err = Api.explain(e);
      nModels = null;
    }
    try {
      q = await qf;
    } catch (_) {
      q = {'rows': <List<String>>[], 'raw': null};
    }
    if (mounted) setState(() => loading = false);
  }

  Widget card(String title, Widget child, {Widget? action}) => Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: line)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(
              child: Text(title,
                  style:
                      const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
          if (action != null) action,
        ]),
        const SizedBox(height: 10),
        child,
      ]));

  Widget kv(String k, String v, {Color? c}) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: Text(k, style: const TextStyle(color: Colors.black54))),
        const SizedBox(width: 12),
        Flexible(
            flex: 2,
            child: Text(v,
                textAlign: TextAlign.right,
                style: TextStyle(fontWeight: FontWeight.w600, color: c))),
      ]));

  String mask(String k) =>
      k.length <= 10 ? '••••' : '${k.substring(0, 6)}••••${k.substring(k.length - 4)}';
  String fmt(int n) => n >= 1000000
      ? '${(n / 1e6).toStringAsFixed(2)}M'
      : n >= 1000
          ? '${(n / 1e3).toStringAsFixed(1)}K'
          : '$n';

  @override
  Widget build(BuildContext context) {
    int ti = 0, to = 0, mx = 1;
    Store.usage.forEach((_, u) {
      ti += u['i'] as int;
      to += u['o'] as int;
      final t = (u['i'] as int) + (u['o'] as int);
      if (t > mx) mx = t;
    });
    final used = Store.monthly[_mk] ?? 0;
    final rows = (q?['rows'] as List?)?.cast<List<String>>() ?? [];
    final raw = q?['raw'] as String?;
    final ok = !loading && err.isEmpty && Api.ready;
    return Scaffold(
      appBar: AppBar(title: const Text('User Dashboard')),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          card(
              'API connection',
              Column(children: [
                kv('Status', loading ? 'Checking…' : (ok ? 'Connected' : 'Not connected'),
                    c: loading ? null : (ok ? Colors.green.shade700 : Colors.red.shade700)),
                if (err.isNotEmpty)
                  Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Text(err,
                          style: TextStyle(color: Colors.red.shade700, fontSize: 13))),
                kv('Base URL', Api.baseUrl.isEmpty ? '—' : Api.baseUrl),
                kv('API key', Api.apiKey.isEmpty ? '—' : mask(Api.apiKey)),
                kv('Format', Api.proto),
                kv('Models available', nModels?.toString() ?? '—'),
              ]),
              action: IconButton(
                  icon: const Icon(Icons.refresh), onPressed: loading ? null : load)),
          card(
              'Key limits and balance',
              rows.isEmpty
                  ? Text(
                      loading
                          ? 'Checking…'
                          : 'This key system does not publish limits at the usual addresses. Usage below is counted on this phone.',
                      style: const TextStyle(color: Colors.black54, height: 1.4))
                  : Column(children: [for (final r in rows) kv(r[0], r[1])])),
          if (Api.rate.isNotEmpty)
            card('Rate limits (last request)',
                Column(children: [for (final e in Api.rate.entries) kv(e.key, e.value)])),
          card(
              'Usage on this phone',
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                kv('This month', '${fmt(used)} tokens'),
                if (Store.limit > 0) ...[
                  const SizedBox(height: 4),
                  ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(
                          minHeight: 8,
                          value: (used / Store.limit).clamp(0.0, 1.0),
                          color: used >= Store.limit ? Colors.red : accent,
                          backgroundColor: soft)),
                  kv('Limit', fmt(Store.limit)),
                ],
                kv('All time', '${fmt(ti)} in · ${fmt(to)} out'),
                kv('Chats saved', '${Store.chats.length}'),
                if (Store.usage.isNotEmpty) const Divider(height: 24),
                for (final e in Store.usage.entries)
                  Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Expanded(
                              child: Text(e.key,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 13.5))),
                          Text(fmt((e.value['i'] as int) + (e.value['o'] as int)),
                              style: const TextStyle(fontWeight: FontWeight.w600)),
                        ]),
                        const SizedBox(height: 4),
                        ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                                minHeight: 5,
                                value: ((e.value['i'] as int) + (e.value['o'] as int)) / mx,
                                color: accent,
                                backgroundColor: soft)),
                      ])),
              ])),
          card(
              'Monthly token limit',
              TextField(
                  controller: lim,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      hintText: '0 = no limit', border: OutlineInputBorder()),
                  onSubmitted: (v) async {
                    Store.limit = int.tryParse(v) ?? 0;
                    await Store.save();
                    if (context.mounted) setState(() {});
                  })),
          if (raw != null)
            Theme(
                data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                child: ExpansionTile(
                    title: const Text('Raw server response'),
                    children: [Padding(padding: const EdgeInsets.all(12), child: SelectableText(raw))])),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
                child: OutlinedButton.icon(
                    icon: const Icon(Icons.upload_outlined),
                    onPressed: () async {
                      await Clipboard.setData(ClipboardData(text: Store.exportAll()));
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                            content: Text('Backup copied. Paste it in a safe place.')));
                      }
                    },
                    label: const Text('Backup'))),
            const SizedBox(width: 12),
            Expanded(
                child: OutlinedButton.icon(
                    icon: const Icon(Icons.download_outlined),
                    onPressed: () async {
                      final d = await Clipboard.getData('text/plain');
                      try {
                        Store.importAll(d?.text ?? '');
                        await Store.save();
                        if (context.mounted) setState(() {});
                      } catch (_) {
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                              content: Text('Clipboard has no valid backup.')));
                        }
                      }
                    },
                    label: const Text('Restore'))),
          ]),
          const SizedBox(height: 24),
        ]),
      ),
    );
  }
}

class PromptsPage extends StatefulWidget {
  const PromptsPage({super.key});
  @override
  State<PromptsPage> createState() => _PromptsPageState();
}

class _PromptsPageState extends State<PromptsPage> {
  Future<void> add() async {
    final c = TextEditingController();
    final t = await showDialog<String>(
        context: context,
        builder: (_) => AlertDialog(
              title: const Text('New prompt'),
              content: TextField(controller: c, maxLines: 5, autofocus: true),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel')),
                FilledButton(
                    onPressed: () => Navigator.pop(context, c.text),
                    child: const Text('Save')),
              ],
            ));
    if (t != null && t.trim().isNotEmpty) {
      Store.prompts.add(t.trim());
      await Store.save();
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Prompt library')),
        floatingActionButton: FloatingActionButton(
            backgroundColor: accent,
            foregroundColor: Colors.white,
            onPressed: add,
            child: const Icon(Icons.add)),
        body: Store.prompts.isEmpty
            ? const Center(child: Text('No saved prompts yet'))
            : ListView(children: [
                for (var i = 0; i < Store.prompts.length; i++)
                  ListTile(
                    title: Text(Store.prompts[i],
                        maxLines: 2, overflow: TextOverflow.ellipsis),
                    onTap: () => Navigator.pop(context, Store.prompts[i]),
                    trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          Store.prompts.removeAt(i);
                          await Store.save();
                          setState(() {});
                        }),
                  )
              ]),
      );
}

class ConnectorsPage extends StatefulWidget {
  const ConnectorsPage({super.key});
  @override
  State<ConnectorsPage> createState() => _ConnectorsPageState();
}

class _ConnectorsPageState extends State<ConnectorsPage> {
  void snack(String s) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  Future<void> add() async {
    final n = TextEditingController(),
        u = TextEditingController(),
        t = TextEditingController();
    final ok = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
              title: const Text('Add MCP server'),
              content: SingleChildScrollView(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  TextField(
                      controller: n,
                      decoration: const InputDecoration(labelText: 'Name')),
                  TextField(
                      controller: u,
                      keyboardType: TextInputType.url,
                      decoration: const InputDecoration(
                          labelText: 'Server URL (https)',
                          hintText: 'https://example.com/mcp')),
                  TextField(
                      controller: t,
                      obscureText: true,
                      decoration: const InputDecoration(
                          labelText: 'Token (leave empty for OAuth sign-in)')),
                ]),
              ),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text('Cancel')),
                FilledButton(
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text('Add')),
              ],
            ));
    if (ok == true && u.text.trim().isNotEmpty) {
      Store.mcps.add({
        'name': n.text.trim().isEmpty ? u.text.trim() : n.text.trim(),
        'url': u.text.trim(),
        'token': t.text.trim(),
        'on': true
      });
      await Store.save();
      setState(() {});
    }
  }

  Future<void> signIn(Map s) async {
    snack('Opening login...');
    try {
      s['oauth'] = await OAuth.login(s['url']);
      await Store.save();
      snack('Signed in.');
      setState(() {});
    } catch (e) {
      snack('Sign-in failed: ${Api.explain(e)}');
    }
  }

  Future<void> test(Map s) async {
    snack('Connecting...');
    try {
      final c = McpClient(s['url'], await OAuth.token(s));
      await c.init();
      final t = await c.tools();
      snack('Connected. ${t.length} tools: ${t.take(5).map((e) => e['name']).join(', ')}');
    } catch (e) {
      snack('Failed: $e');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Connectors (MCP)')),
        floatingActionButton: FloatingActionButton(
            backgroundColor: accent,
            foregroundColor: Colors.white,
            onPressed: add,
            child: const Icon(Icons.add)),
        body: Store.mcps.isEmpty
            ? const Center(
                child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                        'No connectors yet. Tap + to add a remote MCP server.',
                        textAlign: TextAlign.center)))
            : ListView(children: [
                for (final s in Store.mcps)
                  ListTile(
                    title: Text(s['name']),
                    subtitle: Text(s['url'], overflow: TextOverflow.ellipsis),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(
                          tooltip: 'Sign in (OAuth)',
                          icon: Icon(Icons.login,
                              color: s['oauth'] != null ? accent : null),
                          onPressed: () => signIn(s)),
                      IconButton(
                          icon: const Icon(Icons.bolt), onPressed: () => test(s)),
                      IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () async {
                            Store.mcps.remove(s);
                            await Store.save();
                            setState(() {});
                          }),
                      Switch(
                          value: s['on'] == true,
                          activeColor: accent,
                          onChanged: (v) async {
                            s['on'] = v;
                            await Store.save();
                            setState(() {});
                          }),
                    ]),
                  )
              ]),
      );
}

class PreviewPage extends StatefulWidget {
  final String html;
  const PreviewPage(this.html, {super.key});
  @override
  State<PreviewPage> createState() => _PreviewPageState();
}

class _PreviewPageState extends State<PreviewPage> {
  late final WebViewController c = WebViewController()
    ..setJavaScriptMode(JavaScriptMode.unrestricted)
    ..loadHtmlString(widget.html);
  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('Preview')),
      body: WebViewWidget(controller: c));
}

class PersonaPage extends StatefulWidget {
  const PersonaPage({super.key});
  @override
  State<PersonaPage> createState() => _PersonaPageState();
}

class _PersonaPageState extends State<PersonaPage> {
  final p = TextEditingController(text: Store.persona);
  final n = TextEditingController(text: Store.notes);
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Persona & memory')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          const Text('Persona', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          TextField(
              controller: p,
              maxLines: 4,
              decoration: const InputDecoration(
                  hintText: 'e.g. Answer briefly, in Bengali, like a friendly teacher',
                  border: OutlineInputBorder())),
          const SizedBox(height: 18),
          const Text('Memory', style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          TextField(
              controller: n,
              maxLines: 7,
              decoration: const InputDecoration(
                  hintText: 'Things Lumora should always remember about you',
                  border: OutlineInputBorder())),
          const SizedBox(height: 18),
          FilledButton(
              style: FilledButton.styleFrom(backgroundColor: accent),
              onPressed: () async {
                Store.persona = p.text.trim();
                Store.notes = n.text.trim();
                await Store.save();
                if (context.mounted) Navigator.pop(context);
              },
              child: const Text('Save')),
        ]),
      );
}

class ComparePage extends StatefulWidget {
  final List<String> models;
  const ComparePage(this.models, {super.key});
  @override
  State<ComparePage> createState() => _ComparePageState();
}

class _ComparePageState extends State<ComparePage> {
  late String a = widget.models.first;
  late String b =
      widget.models.length > 1 ? widget.models[1] : widget.models.first;
  final q = TextEditingController();
  String ra = '', rb = '';
  bool busy = false;

  Future<void> run(bool first) async {
    final m = first ? a : b;
    try {
      await for (final c in Api.chat(
          m, [{'role': 'user', 'content': q.text}], null)) {
        if (!mounted) return;
        setState(() => first ? ra += c : rb += c);
      }
    } catch (e) {
      if (mounted) setState(() => first ? ra = 'Error: $e' : rb = 'Error: $e');
    }
  }

  Future<void> go() async {
    if (q.text.trim().isEmpty || busy) return;
    setState(() {
      busy = true;
      ra = '';
      rb = '';
    });
    await Future.wait([run(true), run(false)]);
    if (mounted) setState(() => busy = false);
  }

  Widget dd(String v, void Function(String) on) => DropdownButton<String>(
      isExpanded: true,
      value: v,
      items: [
        for (final m in widget.models)
          DropdownMenuItem(
              value: m, child: Text(m, overflow: TextOverflow.ellipsis))
      ],
      onChanged: (x) => setState(() => on(x!)));

  Widget card(String t) => Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: line)),
      child: SelectableText(t.isEmpty ? '…' : t,
          style: const TextStyle(fontSize: 15, height: 1.45, color: ink)));

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Compare models')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          dd(a, (x) => a = x),
          dd(b, (x) => b = x),
          TextField(
              controller: q,
              minLines: 1,
              maxLines: 4,
              decoration: const InputDecoration(
                  hintText: 'Ask both models the same question',
                  border: OutlineInputBorder())),
          const SizedBox(height: 10),
          FilledButton(
              style: FilledButton.styleFrom(backgroundColor: accent),
              onPressed: busy ? null : go,
              child: const Text('Run both')),
          card(ra),
          card(rb),
        ]),
      );
}
