import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'api.dart';
import 'main.dart';
import 'mcp.dart';
import 'oauth.dart';
import 'router.dart';
import 'pages.dart';
import 'store.dart';

const modes = {
  'Chat': "You are Lumora, a helpful assistant. Reply in the user's language.",
  'Cowork':
      "You are Lumora in Cowork mode: plan tasks step by step and help get work done. Reply in the user's language.",
  'Agent': agentPrompt,
  'Code':
      "You are Lumora in Code mode: write clean, correct code with brief explanations. Reply in the user's language.",
};
const agentPrompt =
    "You are Lumora in Agent mode: break the goal into steps, use the available tools repeatedly until the task is done, then summarize what you did. Reply in the user's language.";
const efforts = ['auto', 'low', 'medium', 'high'];

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  Chat chat = _fresh();
  final input = TextEditingController();
  final scroll = ScrollController();
  final stt = SpeechToText();
  final tts = FlutterTts();
  List<String> models = [];
  String? model; // null = Auto
  String mode = 'Chat', effort = 'auto', lang = 'bn_BD', query = '';
  bool busy = false, live = false, listening = false, cancel = false;
  int _lastUi = 0;
  final _bad = <String, int>{};
  final _rc = <String, (Pick, int)>{};
  List<String> pendImgs = [];
  String pendText = '';

  String mcpNote = '';
  final _tc = <String, List<Map<String, dynamic>>>{};
  final _cl = <String, McpClient>{};

  Future<(List<Map<String, dynamic>>, Map<String, (McpClient, String)>)>
      mcpTools() async {
    final tools = <Map<String, dynamic>>[];
    final map = <String, (McpClient, String)>{};
    mcpNote = '';
    var n = 0;
    for (final s in Store.mcps.where((s) => s['on'] == true)) {
      n++;
      try {
        final tok = await OAuth.token(s);
        final c = _cl.putIfAbsent(s['url'], () => McpClient(s['url'], tok));
        c.token = tok;
        if (!_tc.containsKey(s['url'])) {
          await c.init();
          _tc[s['url']] = await c.tools();
        }
        for (final t in _tc[s['url']]!) {
          var nm = 's${n}_${t['name']}'.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_');
          if (nm.length > 64) nm = nm.substring(0, 64);
          map[nm] = (c, t['name'].toString());
          tools.add({
            'type': 'function',
            'function': {
              'name': nm,
              'description': (t['description'] ?? '').toString(),
              'parameters':
                  t['inputSchema'] ?? {'type': 'object', 'properties': {}}
            }
          });
        }
      } catch (err) {
        mcpNote += "MCP '${s['name']}': ${Api.explain(err)}\n";
      }
    }
    return (tools, map);
  }

  Future<void> runTools(
      String m,
      List<Map<String, dynamic>> hist,
      String? e,
      List<Map<String, dynamic>> tools,
      Map<String, (McpClient, String)> tmap,
      Msg reply) async {
    final h = List<Map<String, dynamic>>.from(hist);
    Api.lastIn = Api.lastOut = 0;
    var trace = '';
    for (var i = 0; i < (mode == 'Agent' ? 12 : 6); i++) {
      if (cancel) break;
      final msg = await Api.chatOnce(m, h, e, tools);
      final calls = (msg['tool_calls'] as List?) ?? [];
      if (calls.isEmpty) {
        setState(() => reply.text = trace + (msg['content'] ?? '').toString());
        return;
      }
      h.add({
        'role': 'assistant',
        'content': msg['content'],
        'tool_calls': calls
      });
      for (final c in calls) {
        final fn = c['function'];
        final name = fn['name'] as String;
        trace += '▸ ${tmap[name]?.$2 ?? name}\n';
        setState(() => reply.text = '$trace…');
        String out;
        try {
          Map args = {};
          try {
            args = jsonDecode(fn['arguments'] ?? '{}');
          } catch (_) {}
          out = await tmap[name]!.$1.call(tmap[name]!.$2, args);
        } catch (err) {
          out = 'Tool error: $err';
        }
        h.add({'role': 'tool', 'tool_call_id': c['id'], 'content': out});
      }
    }
    setState(() => reply.text = 'Stopped after too many tool steps.');
  }

  static Chat _fresh() =>
      Chat(DateTime.now().millisecondsSinceEpoch.toString(), 'New chat', []);

  @override
  void initState() {
    super.initState();
    loadPrefs().then((_) => loadModels());
  }

  Future<void> loadPrefs() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      model = p.getString('m_model');
      final md = p.getString('m_mode');
      mode = modes.containsKey(md) ? md! : 'Chat';
      effort = p.getString('m_effort') ?? 'auto';
      lang = p.getString('m_lang') ?? 'bn_BD';
    });
  }

  Future<void> savePrefs() async {
    final p = await SharedPreferences.getInstance();
    model == null ? await p.remove('m_model') : await p.setString('m_model', model!);
    await p.setString('m_mode', mode);
    await p.setString('m_effort', effort);
    await p.setString('m_lang', lang);
  }

  Future<void> loadModels() async {
    if (!Api.ready) return;
    if (models.isEmpty && Api.cached.isNotEmpty) {
      setState(() => models = Api.cached);
    }
    try {
      final m = await Api.models();
      if (mounted) {
        setState(() {
          models = m;
          if (model != null && !m.contains(model)) model = null;
        });
      }
    } catch (e) {
      if (mounted) snack('API check failed: ${Api.explain(e)}');
    }
  }

  void snack(String s) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  List<String> order(bool big) {
    if (model != null) return [model!, ...models.where((m) => m != model)];
    final re = RegExp(big
        ? r'opus|sonnet|pro|gpt-5|o3|large'
        : r'haiku|flash|mini|lite|small');
    final pref = models.where((m) => re.hasMatch(m.toLowerCase())).toList();
    return [...pref, ...models.where((m) => !pref.contains(m))];
  }

  Future<void> send([String? voice]) async {
    final t = (voice ?? input.text).trim();
    if ((t.isEmpty && pendImgs.isEmpty && pendText.isEmpty) || busy) return;
    if (!Api.ready || models.isEmpty) {
      snack('Add your API key in the menu first.');
      return;
    }
    if (Store.limit > 0 &&
        (Store.monthly[DateTime.now().toIso8601String().substring(0, 7)] ?? 0) >=
            Store.limit) {
      snack('Monthly token limit reached. Change it in User Dashboard.');
      return;
    }
    final full = pendText.isEmpty ? t : '$t\n\n---\n$pendText';
    final hadImg = pendImgs.isNotEmpty || chat.msgs.any((m) => m.images.isNotEmpty);
    final reply = Msg(false, '');
    final past = chat.msgs.length > 40
        ? chat.msgs.sublist(chat.msgs.length - 40)
        : List<Msg>.of(chat.msgs);
    if (past.isNotEmpty && !past.first.user) past.removeAt(0);
    final hist = <Map<String, dynamic>>[
      {
        'role': 'system',
        'content': modes[mode]! +
            (Store.persona.isEmpty ? '' : '\n\nPersona: ${Store.persona}') +
            (Store.notes.isEmpty
                ? ''
                : '\n\nThings to remember about the user:\n${Store.notes}')
      },
      for (final m in past)
        {
          'role': m.user ? 'user' : 'assistant',
          'content': m.images.isEmpty
              ? m.text
              : [
                  {'type': 'text', 'text': m.text},
                  for (final i in m.images)
                    {'type': 'image_url', 'image_url': {'url': i}}
                ]
        },
      {
        'role': 'user',
        'content': pendImgs.isEmpty
            ? full
            : [
                {'type': 'text', 'text': full},
                for (final i in pendImgs)
                  {'type': 'image_url', 'image_url': {'url': i}}
              ]
      },
    ];
    setState(() {
      chat.msgs
        ..add(Msg(true, full, List.of(pendImgs)))
        ..add(reply);
      if (chat.title == 'New chat') {
        chat.title = (t.isEmpty ? 'Attachment' : t)
            .substring(0, (t.isEmpty ? 10 : t.length).clamp(0, 30));
      }
      if (!Store.chats.contains(chat)) Store.chats.insert(0, chat);
      busy = true;
    });
    input.clear();
    pendImgs = [];
    pendText = '';
    final (tools, tmap) = await mcpTools();
    final task = AutoRouter.classify(full, mode, tools.isNotEmpty, hadImg);
    final smart =
        model == null && (task.cx > 0 || task.vision || tools.isNotEmpty);
    if (smart) setState(() => reply.note = 'Choosing the best model…');
    final pickR =
        smart ? await smartPick(task, full) : AutoRouter.pick(models, task, _bad);
    final o = model != null
        ? [model!, ...pickR.order.where((x) => x != model)]
        : pickR.order;
    final lv = ['low', 'medium', 'high'][task.cx];
    final String? eff = effort != 'auto'
        ? effort
        : (model == null
            ? pickR.effort
            : (AutoRouter.profile(model!).reason ? lv : null));
    final tries = <(String, String?, bool)>[
      (o.first, eff, true),
      if (eff != null) (o.first, null, true),
      if (tools.isNotEmpty) (o.first, null, false),
      if (o.length > 1) (o[1], null, false),
      if (o.length > 2) (o[2], null, false),
    ];
    String used = o.first;
    for (final (m, e, useT) in tries) {
      try {
        used = m;
        if (!useT && tools.isNotEmpty && mcpNote.isEmpty) {
          mcpNote = 'This model or server rejected tool use, so it answered without tools.';
        }
        reply.text = '';
        if (useT && tools.isNotEmpty) {
          await runTools(m, hist, e, tools, tmap, reply);
        } else {
          await for (final c in Api.chat(m, hist, e)) {
            if (cancel) break;
            reply.text += c;
            final now = DateTime.now().millisecondsSinceEpoch;
            if (now - _lastUi > 60) {
              _lastUi = now;
              setState(() {});
              if (scroll.hasClients) {
                scroll.jumpTo(scroll.position.maxScrollExtent);
              }
            }
          }
        }
        break;
      } catch (err) {
        reply.text = 'Error: $err';
        if (e == null && (!useT || tools.isEmpty)) {
          _bad[m] = DateTime.now().millisecondsSinceEpoch;
        }
      }
    }
    if (model == null) {
      reply.note =
          'Auto → $used · ${pickR.why}${eff != null ? ' · effort $eff' : ''}';
    }
    cancel = false;
    if (mounted) setState(() {});
    if (reply.text.isEmpty) reply.text = '(stopped)';
    final ok = !reply.text.startsWith('Error: ');
    if (mcpNote.isNotEmpty && ok) {
      setState(() => reply.text = '⚠ ${mcpNote.trim()}\n\n${reply.text}');
    }
    Store.addUsage(
        used,
        Api.lastIn > 0 ? Api.lastIn : full.length ~/ 4,
        Api.lastOut > 0 ? Api.lastOut : reply.text.length ~/ 4);
    await Store.save();
    if (mounted) setState(() => busy = false);
    if (live) {
      ok ? tts.speak(reply.text.replaceAll(RegExp(r'[*#`_]'), '')) : liveListen();
    }
  }

  Future<void> attach() async {
    final r = await FilePicker.platform.pickFiles(withData: true);
    if (r == null || r.files.single.bytes == null) return;
    final f = r.files.single;
    final ext = (f.extension ?? '').toLowerCase();
    if (['png', 'jpg', 'jpeg', 'webp'].contains(ext)) {
      pendImgs.add(
          'data:image/${ext == 'jpg' ? 'jpeg' : ext};base64,${base64Encode(f.bytes!)}');
    } else {
      pendText += '[${f.name}]\n${utf8.decode(f.bytes!, allowMalformed: true)}\n';
    }
    setState(() {});
  }

  Future<bool> sttInit() =>
      stt.initialize(onError: (e) => snack('Speech: ${e.errorMsg}'));

  Future<String?> loc() async {
    final ls = (await stt.locales()).map((l) => l.localeId).toList();
    final norm = lang.toLowerCase();
    for (final l in ls) {
      if (l.toLowerCase().replaceAll('-', '_') == norm) return l;
    }
    final pre = lang.startsWith('bn') ? 'bn' : 'en';
    for (final l in ls) {
      if (l.toLowerCase().startsWith(pre)) return l;
    }
    if (lang.startsWith('bn')) {
      snack('Bengali speech recognition not found on this phone. Install Bengali in Google app/keyboard voice settings.');
    }
    return null;
  }

  Future<void> setupTts() async {
    final want = lang.startsWith('bn') ? ['bn-BD', 'bn-IN', 'bn'] : ['en-US'];
    for (final l in want) {
      if (await tts.isLanguageAvailable(l) == true) {
        await tts.setLanguage(l);
        return;
      }
    }
    snack(lang.startsWith('bn')
        ? 'Bengali voice not installed. Phone Settings > Text-to-speech > Google > install Bengali voice data.'
        : 'Voice not available.');
  }

  Future<void> mic() async {
    if (listening) {
      await stt.stop();
      setState(() => listening = false);
      return;
    }
    if (!await sttInit()) {
      snack('Speech recognition is not available.');
      return;
    }
    setState(() => listening = true);
    stt.listen(
        localeId: await loc(),
        onResult: (r) {
          input.text = r.recognizedWords;
          if (r.finalResult && mounted) setState(() => listening = false);
        });
  }

  Future<void> toggleLive() async {
    if (live) {
      live = false;
      await tts.stop();
      await stt.stop();
      setState(() {});
      return;
    }
    if (!await sttInit()) {
      snack('Speech recognition is not available.');
      return;
    }
    await setupTts();
    tts.setCompletionHandler(() {
      if (live) liveListen();
    });
    setState(() => live = true);
    liveListen();
  }

  Future<void> liveListen() async {
    if (!live || busy) return;
    stt.listen(
        localeId: await loc(),
        pauseFor: const Duration(seconds: 2),
        onResult: (r) {
          if (!r.finalResult) return;
          r.recognizedWords.trim().isEmpty ? liveListen() : send(r.recognizedWords);
        });
  }

  void toolsSheet() => showModalBottomSheet(
      context: context,
      backgroundColor: bg,
      builder: (_) => SafeArea(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              ListTile(
                  leading: const Icon(Icons.attach_file),
                  title: const Text('Attach file or image'),
                  onTap: () {
                    Navigator.pop(context);
                    attach();
                  }),
              ListTile(
                  leading: const Icon(Icons.bookmark_border),
                  title: const Text('Prompt library'),
                  onTap: () async {
                    Navigator.pop(context);
                    final p = await Navigator.push<String>(context,
                        MaterialPageRoute(builder: (_) => const PromptsPage()));
                    if (p != null) setState(() => input.text = p);
                  }),
              ListTile(
                  leading: const Icon(Icons.compare_arrows),
                  title: const Text('Compare two models'),
                  onTap: () {
                    Navigator.pop(context);
                    if (models.isEmpty) {
                      snack('Add your API key first.');
                      return;
                    }
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => ComparePage(models)));
                  }),
              _pick('Mode', Icons.tune, mode, modes.keys.toList(),
                  (v) {
                    setState(() => mode = v);
                    savePrefs();
                  }),
              _pick('Thinking effort', Icons.psychology_outlined, effort,
                  efforts, (v) {
                    setState(() => effort = v);
                    savePrefs();
                  }),
              _pick('Voice language', Icons.language, lang,
                  ['bn_BD', 'en_US'], (v) {
                    setState(() => lang = v);
                    savePrefs();
                  }),
            ]),
          ));

  Widget _pick(String title, IconData icon, String cur, List<String> items,
          void Function(String) on) =>
      ListTile(
        leading: Icon(icon),
        title: Text(title),
        trailing: DropdownButton<String>(
            value: cur,
            underline: const SizedBox(),
            items: [
              for (final i in items) DropdownMenuItem(value: i, child: Text(i))
            ],
            onChanged: (v) {
              on(v!);
              Navigator.pop(context);
            }),
      );

  void modelSheet() {
    var q = '';
    showModalBottomSheet(
        context: context,
        backgroundColor: bg,
        isScrollControlled: true,
        builder: (_) => StatefulBuilder(builder: (ctx, set) {
              final list = models
                  .where((m) => m.toLowerCase().contains(q.toLowerCase()))
                  .toList();
              return SafeArea(
                  child: Padding(
                      padding: EdgeInsets.only(
                          bottom: MediaQuery.of(ctx).viewInsets.bottom),
                      child: ConstrainedBox(
                          constraints: BoxConstraints(
                              maxHeight: MediaQuery.of(ctx).size.height * 0.75),
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            Padding(
                                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                                child: TextField(
                                    onChanged: (v) => set(() => q = v),
                                    decoration: InputDecoration(
                                        isDense: true,
                                        hintText: 'Search ${models.length} models',
                                        prefixIcon: const Icon(Icons.search),
                                        filled: true,
                                        fillColor: soft,
                                        border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(14),
                                            borderSide: BorderSide.none)))),
                            Flexible(
                                child: ListView(shrinkWrap: true, children: [
                              if (q.isEmpty)
                                ListTile(
                                    title: const Text('Auto (best model for the task)'),
                                    trailing: model == null
                                        ? const Icon(Icons.check, color: accent)
                                        : null,
                                    onTap: () {
                                      setState(() => model = null);
                                      savePrefs();
                                      Navigator.pop(ctx);
                                    }),
                              for (final m in list)
                                ListTile(
                                    dense: true,
                                    title: Text(m),
                                    trailing: model == m
                                        ? const Icon(Icons.check, color: accent)
                                        : null,
                                    onTap: () {
                                      setState(() => model = m);
                                      savePrefs();
                                      Navigator.pop(ctx);
                                    }),
                            ])),
                          ]))));
            }));
  }

  Future<Pick> smartPick(Task k, String text) async {
    final local = AutoRouter.pick(models, k, _bad);
    final now = DateTime.now().millisecondsSinceEpoch;
    final key = '${k.kind}:${k.cx}:${k.vision}:${k.tools}:${models.length}';
    final hit = _rc[key];
    if (hit != null &&
        now - hit.$2 < 1200000 &&
        !_bad.containsKey(hit.$1.order.first)) {
      return hit.$1;
    }
    final rm = AutoRouter.routerModel(models, _bad);
    if (rm == null) return local;
    try {
      final top = local.order.take(60).toList();
      final lvl = ['simple', 'moderate', 'complex'][k.cx];
      final out = await Api.quick(
          rm,
          AutoRouter.routerPrompt,
          'Models: ${top.join(', ')}\n'
          'Task type: ${k.kind}; complexity: $lvl; image attached: ${k.vision ? 'yes' : 'no'}; tools needed: ${k.tools ? 'yes' : 'no'}; mode: $mode.\n'
          'Task: ${text.length > 500 ? text.substring(0, 500) : text}\n'
          'Local ranking hint (best first): ${top.take(5).join(', ')}');
      Store.addUsage(rm, (AutoRouter.routerPrompt.length + 600) ~/ 4, 40);
      final m = RegExp(r'\{[^{}]*\}').firstMatch(out);
      if (m != null) {
        final j = jsonDecode(m.group(0)!);
        final id = j['model']?.toString();
        if (id != null && top.contains(id)) {
          final e = j['effort']?.toString();
          final eff = ['low', 'medium', 'high'].contains(e) &&
                  AutoRouter.profile(id).reason
              ? e
              : null;
          final p = Pick([id, ...local.order.where((x) => x != id)], eff,
              '${j['reason'] ?? k.kind} (AI-chosen)');
          _rc[key] = (p, now);
          return p;
        }
      }
    } catch (_) {
      _bad[rm] = now;
    }
    return local;
  }

  Future<void> regen() async {
    if (busy || chat.msgs.length < 2) return;
    final u = chat.msgs[chat.msgs.length - 2];
    chat.msgs.removeRange(chat.msgs.length - 2, chat.msgs.length);
    pendImgs = List.of(u.images);
    await send(u.text);
  }

  void editLast() {
    if (busy || chat.msgs.length < 2) return;
    final u = chat.msgs[chat.msgs.length - 2];
    setState(() {
      chat.msgs.removeRange(chat.msgs.length - 2, chat.msgs.length);
      input.text = u.text;
      pendImgs = List.of(u.images);
    });
  }

  List<InlineSpan> inl(String s) {
    final out = <InlineSpan>[];
    final re = RegExp(r'\*\*(.+?)\*\*|`([^`]+)`');
    var i = 0;
    for (final m in re.allMatches(s)) {
      if (m.start > i) out.add(TextSpan(text: s.substring(i, m.start)));
      if (m.group(1) != null) {
        out.add(TextSpan(
            text: m.group(1),
            style: const TextStyle(fontWeight: FontWeight.w700)));
      } else {
        out.add(TextSpan(
            text: m.group(2),
            style: const TextStyle(
                fontFamily: 'monospace', backgroundColor: soft)));
      }
      i = m.end;
    }
    if (i < s.length) out.add(TextSpan(text: s.substring(i)));
    return out;
  }

  Widget line(String l, TextStyle base) {
    final h = RegExp(r'^#{1,6}\s+(.*)').firstMatch(l);
    if (h != null) {
      return SelectableText.rich(TextSpan(
          style: base.copyWith(fontSize: 19, fontWeight: FontWeight.w700),
          children: inl(h.group(1)!)));
    }
    final b = RegExp(r'^\s*[-*]\s+(.*)').firstMatch(l);
    if (b != null) {
      return Padding(
          padding: const EdgeInsets.only(left: 12),
          child: SelectableText.rich(TextSpan(
              style: base,
              children: [const TextSpan(text: '•  '), ...inl(b.group(1)!)])));
    }
    return SelectableText.rich(TextSpan(style: base, children: inl(l)));
  }

  Widget md(String t) {
    final bn = RegExp('[\\u0980-\\u09FF]').hasMatch(t);
    final base = TextStyle(
        fontSize: 16.5,
        height: 1.5,
        color: ink,
        fontFamily: bn ? null : 'serif');
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      for (final raw in t.split('\n'))
        if (raw.trim().isNotEmpty)
          Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: line(raw.trimRight(), base)),
    ]);
  }

  Widget code(String raw) {
    final nl = raw.indexOf('\n');
    final lang = nl > 0 ? raw.substring(0, nl).trim().toLowerCase() : '';
    final src = nl >= 0 ? raw.substring(nl + 1) : raw;
    return Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
            color: const Color(0xFF1F1E1B),
            borderRadius: BorderRadius.circular(12)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Padding(
                padding: const EdgeInsets.only(left: 12),
                child: Text(lang.isEmpty ? 'code' : lang,
                    style: const TextStyle(color: Colors.white54, fontSize: 12))),
            const Spacer(),
            if (lang == 'html')
              TextButton(
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => PreviewPage(src))),
                  child: const Text('Preview')),
            IconButton(
                iconSize: 18,
                color: Colors.white54,
                icon: const Icon(Icons.copy_outlined),
                onPressed: () => Clipboard.setData(ClipboardData(text: src))),
          ]),
          SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              child: SelectableText(src,
                  style: const TextStyle(
                      fontFamily: 'monospace',
                      fontSize: 13,
                      color: Color(0xFFEDEBE4)))),
        ]));
  }

  Widget body(String t) {
    final parts = t.split('```');
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      for (var i = 0; i < parts.length; i++)
        if (i.isOdd)
          code(parts[i])
        else if (parts[i].trim().isNotEmpty)
          md(parts[i].trim()),
    ]);
  }

  Widget bubble(Msg m) {
    final w = MediaQuery.of(context).size.width * 0.86;
    if (m.user) {
      return Align(
          alignment: Alignment.centerRight,
          child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Container(
              margin: const EdgeInsets.only(top: 14, left: 40),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              constraints: BoxConstraints(maxWidth: w),
              decoration: BoxDecoration(
                  color: soft, borderRadius: BorderRadius.circular(18)),
              child: SelectableText(
                  m.images.isEmpty ? m.text : '🖼 ${m.images.length}  ${m.text}',
                  style: const TextStyle(fontSize: 16, height: 1.4, color: ink))),
            if (!busy && chat.msgs.indexOf(m) == chat.msgs.length - 2)
              IconButton(
                  visualDensity: VisualDensity.compact,
                  iconSize: 18,
                  color: Colors.black45,
                  icon: const Icon(Icons.edit_outlined),
                  onPressed: editLast),
          ]));
    }
    return Padding(
        padding: const EdgeInsets.only(top: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          m.text.isEmpty ? const Text('…') : body(m.text),
          if (m.note.isNotEmpty)
            Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Text(m.note,
                    style: const TextStyle(fontSize: 11.5, color: Colors.black45))),
          if (m.text.isNotEmpty)
            Row(mainAxisSize: MainAxisSize.min, children: [
              IconButton(
                  visualDensity: VisualDensity.compact,
                  iconSize: 18,
                  color: Colors.black45,
                  icon: const Icon(Icons.copy_outlined),
                  onPressed: () =>
                      Clipboard.setData(ClipboardData(text: m.text))),
              if (!busy && chat.msgs.last == m)
                IconButton(
                    visualDensity: VisualDensity.compact,
                    iconSize: 18,
                    color: Colors.black45,
                    icon: const Icon(Icons.refresh),
                    onPressed: regen),
            ]),
        ]));
  }

  Widget drawer() => Drawer(
        child: SafeArea(
          child: StatefulBuilder(builder: (ctx, set) {
            final list = Store.chats
                .where((c) =>
                    c.title.toLowerCase().contains(query.toLowerCase()) ||
                    c.msgs.any((m) =>
                        query.isNotEmpty &&
                        m.text.toLowerCase().contains(query.toLowerCase())))
                .toList();
            return Column(children: [
              ListTile(
                  leading: Image.asset('assets/mark.png', width: 34),
                  title: const Text('Lumora',
                      style: TextStyle(
                          fontSize: 24,
                          fontFamily: 'serif',
                          fontWeight: FontWeight.w600))),
              Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: TextField(
                      onChanged: (v) => set(() => query = v),
                      decoration: InputDecoration(
                          isDense: true,
                          hintText: 'Search chats',
                          prefixIcon: const Icon(Icons.search),
                          filled: true,
                          fillColor: soft,
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide: BorderSide.none)))),
              ListTile(
                  leading: const Icon(Icons.add_circle_outline),
                  title: const Text('New chat'),
                  onTap: () {
                    setState(() => chat = _fresh());
                    Navigator.pop(ctx);
                  }),
              Expanded(
                  child: ListView(children: [
                for (final c in list)
                  ListTile(
                      dense: true,
                      selected: c == chat,
                      title: Text(c.title, overflow: TextOverflow.ellipsis),
                      onTap: () {
                        setState(() => chat = c);
                        Navigator.pop(ctx);
                      },
                      trailing: IconButton(
                          icon: const Icon(Icons.close, size: 18),
                          onPressed: () async {
                            Store.chats.remove(c);
                            if (c == chat) chat = _fresh();
                            await Store.save();
                            set(() {});
                            setState(() {});
                          })),
              ])),
              const Divider(height: 1),
              ListTile(
                  leading: const Icon(Icons.psychology_alt_outlined),
                  title: const Text('Persona & memory'),
                  onTap: () {
                    Navigator.pop(ctx);
                    Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const PersonaPage()));
                  }),
              ListTile(
                  leading: const Icon(Icons.hub_outlined),
                  title: const Text('Connectors (MCP)'),
                  onTap: () async {
                    Navigator.pop(ctx);
                    await Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const ConnectorsPage()));
                    _tc.clear();
                    _cl.clear();
                  }),
              ListTile(
                  leading: const Icon(Icons.dashboard_outlined),
                  title: const Text('User Dashboard'),
                  onTap: () {
                    Navigator.pop(ctx);
                    Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const DashboardPage()));
                  }),
              ListTile(
                  leading: const Icon(Icons.key),
                  title: const Text('API key'),
                  onTap: () async {
                    Navigator.pop(ctx);
                    await Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const SettingsPage()));
                    loadModels();
                  }),
            ]);
          }),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: GestureDetector(
              onTap: modelSheet,
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Flexible(
                    child: Text(model ?? 'Lumora · Auto',
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w600))),
                const Icon(Icons.expand_more, size: 20),
              ])),
        ),
        drawer: drawer(),
        body: SafeArea(
          child: Column(children: [
            Expanded(
              child: chat.msgs.isEmpty
                  ? Center(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Image.asset('assets/logo.png', width: 132),
                      const SizedBox(height: 18),
                      Text(live ? 'Listening…' : 'How can I help you today?',
                          style: const TextStyle(
                              fontSize: 26, fontFamily: 'serif', color: ink)),
                    ]))
                  : ListView.builder(
                      controller: scroll,
                      padding: const EdgeInsets.fromLTRB(18, 4, 18, 12),
                      itemCount: chat.msgs.length,
                      itemBuilder: (_, i) => bubble(chat.msgs[i])),
            ),
            if (busy)
              const Padding(
                  padding: EdgeInsets.only(bottom: 6),
                  child: Icon(Icons.auto_awesome, color: accent, size: 20)),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              child: Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(26),
                    border: Border.all(color: line)),
                padding: const EdgeInsets.fromLTRB(6, 4, 6, 4),
                child: Column(children: [
                  if (pendImgs.isNotEmpty || pendText.isNotEmpty)
                    Align(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                            padding: const EdgeInsets.only(left: 10, top: 6),
                            child: InputChip(
                                label: Text(
                                    '${pendImgs.length} image · ${pendText.isEmpty ? 0 : 1} file'),
                                onDeleted: () => setState(() {
                                      pendImgs = [];
                                      pendText = '';
                                    })))),
                  if (input.text.isNotEmpty)
                    Align(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                            padding: const EdgeInsets.only(left: 14, top: 4),
                            child: Text(
                                '≈ ${(input.text.length + chat.msgs.fold<int>(0, (a, m) => a + m.text.length)) ~/ 4} input tokens',
                                style: const TextStyle(
                                    fontSize: 11.5, color: Colors.black45)))),
                  Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    IconButton(
                        icon: const Icon(Icons.add), onPressed: toolsSheet),
                    Expanded(
                        child: TextField(
                            controller: input,
                            minLines: 1,
                            maxLines: 6,
                            onChanged: (_) => setState(() {}),
                            decoration: InputDecoration(
                                hintText: listening
                                    ? 'Listening…'
                                    : 'Message Lumora',
                                border: InputBorder.none,
                                contentPadding:
                                    const EdgeInsets.symmetric(vertical: 12)))),
                    IconButton(
                        icon: Icon(listening ? Icons.stop_circle : Icons.mic_none,
                            color: listening ? accent : null),
                        onPressed: mic),
                    busy
                        ? IconButton.filled(
                            style: IconButton.styleFrom(backgroundColor: ink),
                            icon: const Icon(Icons.stop),
                            onPressed: () => setState(() => cancel = true))
                        : input.text.trim().isEmpty && pendImgs.isEmpty && pendText.isEmpty
                        ? IconButton.filled(
                            style:
                                IconButton.styleFrom(backgroundColor: live ? accent : ink),
                            icon: Icon(live ? Icons.close : Icons.graphic_eq),
                            onPressed: toggleLive)
                        : IconButton.filled(
                            style: IconButton.styleFrom(backgroundColor: accent),
                            icon: const Icon(Icons.arrow_upward),
                            onPressed: busy ? null : () => send()),
                  ]),
                ]),
              ),
            ),
          ]),
        ),
      );
}
