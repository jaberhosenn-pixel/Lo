import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class Msg {
  final bool user;
  String text;
  List<String> images;
  String note = '';
  Msg(this.user, this.text, [List<String>? i]) : images = i ?? [];
  Map<String, dynamic> toJson() => {'u': user, 't': text, 'i': images};
  static Msg from(Map j) =>
      Msg(j['u'], j['t'], List<String>.from(j['i'] ?? []));
}

class Chat {
  String id, title;
  List<Msg> msgs;
  Chat(this.id, this.title, this.msgs);
  Map<String, dynamic> toJson() =>
      {'id': id, 'title': title, 'm': msgs.map((e) => e.toJson()).toList()};
  static Chat from(Map j) => Chat(j['id'], j['title'],
      (j['m'] as List).map((e) => Msg.from(e)).toList());
}

class Store {
  static late SharedPreferences p;
  static List<Chat> chats = [];
  static List<String> prompts = [];
  static Map<String, dynamic> usage = {};
  static List<Map<String, dynamic>> mcps = [];
  static String persona = '', notes = '';
  static Map<String, int> monthly = {};
  static int limit = 0;

  static Future<void> load() async {
    p = await SharedPreferences.getInstance();
    importAll(p.getString('all') ?? '{}');
  }

  static String exportAll() => jsonEncode({
        'chats': chats.map((e) => e.toJson()).toList(),
        'prompts': prompts,
        'usage': usage,
        'mcps': mcps,
        'persona': persona,
        'notes': notes,
        'monthly': monthly,
        'limit': limit,
      });

  static void importAll(String s) {
    final d = jsonDecode(s);
    chats = ((d['chats'] ?? []) as List).map((e) => Chat.from(e)).toList();
    prompts = List<String>.from(d['prompts'] ?? []);
    usage = Map<String, dynamic>.from(d['usage'] ?? {});
    persona = d['persona'] ?? '';
    notes = d['notes'] ?? '';
    monthly = Map<String, int>.from(d['monthly'] ?? {});
    limit = d['limit'] ?? 0;
    mcps = ((d['mcps'] ?? []) as List)
        .map((e) => Map<String, dynamic>.from(e))
        .toList();
  }

  static Future<void> save() => p.setString('all', exportAll());

  static void addUsage(String model, int i, int o) {
    final u = Map<String, dynamic>.from(usage[model] ?? {'i': 0, 'o': 0, 'n': 0});
    final mk = DateTime.now().toIso8601String().substring(0, 7);
    monthly[mk] = (monthly[mk] ?? 0) + i + o;
    usage[model] = {'i': u['i'] + i, 'o': u['o'] + o, 'n': u['n'] + 1};
  }
}
