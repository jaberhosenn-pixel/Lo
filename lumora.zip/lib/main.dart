import 'package:flutter/material.dart';
import 'api.dart';
import 'chat_page.dart';
import 'store.dart';

const bg = Color(0xFFFAF9F5);
const accent = Color(0xFFC96442);
const ink = Color(0xFF29261F);
const line = Color(0xFFE6E3D9);
const soft = Color(0xFFF0EEE6);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Api.load();
  await Store.load();
  runApp(const LumoraApp());
}

class LumoraApp extends StatelessWidget {
  const LumoraApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Lumora',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: bg,
          colorScheme: ColorScheme.fromSeed(
              seedColor: accent, brightness: Brightness.light, surface: bg),
          appBarTheme: const AppBarTheme(
              backgroundColor: bg,
              elevation: 0,
              scrolledUnderElevation: 0,
              centerTitle: true,
              foregroundColor: ink,
              surfaceTintColor: Colors.transparent),
          drawerTheme: const DrawerThemeData(backgroundColor: bg),
        ),
        home: const ChatPage(),
      );
}
